package com.thread;

public class Test extends Thread {
@Override
public void run()
{
	System.out.println("Thread Task");
}
	public static void main(String[] args) {
		Test test=new Test();
		test.start();
		
	}

}
