package com.thread;

public class Testrunnable implements Runnable {

	public static void main(String[] args) {
		Testrunnable test1=new Testrunnable();
		Thread th=new Thread(test1);
		th.start();
	}

	@Override
	public void run() {
		System.out.println("You are in run method");
	}

}
